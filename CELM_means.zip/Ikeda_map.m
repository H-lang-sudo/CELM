function[P,T,TV]=Ikeda_map()
%Ikeda Map 
clc;clear;

a =6;b = 0.9; c = 1; 
x(1) = 0;
y(1) = 0;
w(1) = 0;
n(1) = 0;
for i = 2:4000
    n(i) = i;
    x(i) = c + b*( x(i-1)*cos( w(i-1) ) - y(i-1) * sin( w(i-1) ) );%ʵ��
    y(i) = b*(  x(i-1)*sin( w(i-1) ) + y(i-1) * cos(w(i-1) )  );%�鲿
    w(i) = 0.4-a/( 1+x(i)*x(i)+y(i)*y(i) );   
end 
z=x+1i.*y;
plot(real(z),imag(z),'.')
% subplot(1,1,1);
% scatter(x,y,'.');
% title('X-Yͼ��') ;
X=z(:,1:end-1);
Y=z(:,2:end);
train_num=fix(0.7*size(X,2));
P=X(:,1:train_num);
Y=Y';
T=Y(1:train_num,:);

TV.P=X(:,train_num+1:end);
TV.T=Y(train_num+1:end,:);
figure(1)
plot(real(z),imag(z),'.');
%% �����Բ�ȣ������⣩
miu=mean(z,2);
N=size(z,1);
Czz=zeros(N,N);
Pzz=zeros(N,N);
for i=1:size(z,2)
    Czz=Czz+(z(:,i)-miu)*(z(:,i)-miu)';
    Pzz=Pzz+(z(:,i)-miu)*(z(:,i)-miu).';
end
Czz=Czz/size(z,2);
Pzz=Pzz/size(z,2);
Czz_a=[Czz Pzz;conj(Pzz) conj(Czz)];
s=1-det(Czz_a)*(det(Czz))^(-2);
